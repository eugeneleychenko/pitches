# StackOverflow 51383319 - TradingView Scrolling Ticker Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/eugeneleychenko/pen/QWBEQdq](https://codepen.io/eugeneleychenko/pen/QWBEQdq).

